package com.example.macstudent.day_1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
public class LoginActivity extends AppCompatActivity implements View.OnClickListener
{
Button btn_Login;
Button btn_Register;
EditText editUserName;
EditText editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    btn_Login = (Button) findViewById(R.id.btn_Login);
        btn_Login.setOnClickListener(this);
    btn_Register = (Button) findViewById(R.id.btn_Register);
        btn_Register.setOnClickListener(this);
    editUserName=(EditText) findViewById(R.id.UserName);
    editPassword=(EditText) findViewById(R.id.Password);
    }

    @Override
    public void onClick(View view)
    {
        if(view.getId()==btn_Login.getId())
        {
            String uname = editUserName.getText().toString();
            String Password = editPassword.getText().toString();
            Toast.makeText(this, uname + " " + Password, Toast.LENGTH_LONG).show();

        }
        else if (view.getId()==btn_Register.getId())
        {
            Toast.makeText(this, "Register Clicked", Toast.LENGTH_LONG).show();
        }
    }
}